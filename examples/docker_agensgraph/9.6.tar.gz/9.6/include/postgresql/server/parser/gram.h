
/* A Bison parser, made by GNU Bison 2.4.1.  */

/* Skeleton interface for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     IDENT = 258,
     FCONST = 259,
     SCONST = 260,
     BCONST = 261,
     XCONST = 262,
     Op = 263,
     ICONST = 264,
     PARAM = 265,
     TYPECAST = 266,
     DOT_DOT = 267,
     COLON_EQUALS = 268,
     EQUALS_GREATER = 269,
     LESS_EQUALS = 270,
     GREATER_EQUALS = 271,
     NOT_EQUALS = 272,
     ADD_EQUALS = 273,
     ABORT_P = 274,
     ABSOLUTE_P = 275,
     ACCESS = 276,
     ACTION = 277,
     ADD_P = 278,
     ADMIN = 279,
     AFTER = 280,
     AGGREGATE = 281,
     ALL = 282,
     ALLSHORTESTPATHS = 283,
     ALSO = 284,
     ALTER = 285,
     ALWAYS = 286,
     ANALYSE = 287,
     ANALYZE = 288,
     AND = 289,
     ANY = 290,
     ARRAY = 291,
     AS = 292,
     ASC = 293,
     ASSERT = 294,
     ASSERTION = 295,
     ASSIGNMENT = 296,
     ASYMMETRIC = 297,
     AT = 298,
     ATTRIBUTE = 299,
     AUTHORIZATION = 300,
     BACKWARD = 301,
     BEFORE = 302,
     BEGIN_P = 303,
     BETWEEN = 304,
     BIGINT = 305,
     BINARY = 306,
     BIT = 307,
     BOOLEAN_P = 308,
     BOTH = 309,
     BY = 310,
     CACHE = 311,
     CALLED = 312,
     CASCADE = 313,
     CASCADED = 314,
     CASE = 315,
     CAST = 316,
     CATALOG_P = 317,
     CHAIN = 318,
     CHAR_P = 319,
     CHARACTER = 320,
     CHARACTERISTICS = 321,
     CHECK = 322,
     CHECKPOINT = 323,
     CLASS = 324,
     CLOSE = 325,
     CLUSTER = 326,
     COALESCE = 327,
     COLLATE = 328,
     COLLATION = 329,
     COLUMN = 330,
     COMMENT = 331,
     COMMENTS = 332,
     COMMIT = 333,
     COMMITTED = 334,
     CONCURRENTLY = 335,
     CONFIGURATION = 336,
     CONFLICT = 337,
     CONNECTION = 338,
     CONSTRAINT = 339,
     CONSTRAINTS = 340,
     CONTENT_P = 341,
     CONTINUE_P = 342,
     CONVERSION_P = 343,
     COPY = 344,
     COST = 345,
     CREATE = 346,
     CROSS = 347,
     CSV = 348,
     CUBE = 349,
     CURRENT_P = 350,
     CURRENT_CATALOG = 351,
     CURRENT_DATE = 352,
     CURRENT_ROLE = 353,
     CURRENT_SCHEMA = 354,
     CURRENT_TIME = 355,
     CURRENT_TIMESTAMP = 356,
     CURRENT_USER = 357,
     CURSOR = 358,
     CYCLE = 359,
     DATA_P = 360,
     DATABASE = 361,
     DAY_P = 362,
     DEALLOCATE = 363,
     DEC = 364,
     DECIMAL_P = 365,
     DECLARE = 366,
     DEFAULT = 367,
     DEFAULTS = 368,
     DEFERRABLE = 369,
     DEFERRED = 370,
     DEFINER = 371,
     DELETE_P = 372,
     DELIMITER = 373,
     DELIMITERS = 374,
     DEPENDS = 375,
     DESC = 376,
     DETACH = 377,
     DICTIONARY = 378,
     DIJKSTRA = 379,
     DISABLE_P = 380,
     DISCARD = 381,
     DISTINCT = 382,
     DO = 383,
     DOCUMENT_P = 384,
     DOMAIN_P = 385,
     DOUBLE_P = 386,
     DROP = 387,
     EACH = 388,
     ELABEL = 389,
     ELSE = 390,
     ENABLE_P = 391,
     ENCODING = 392,
     ENCRYPTED = 393,
     END_P = 394,
     ENUM_P = 395,
     ESCAPE = 396,
     EVENT = 397,
     EXCEPT = 398,
     EXCLUDE = 399,
     EXCLUDING = 400,
     EXCLUSIVE = 401,
     EXECUTE = 402,
     EXISTS = 403,
     EXPLAIN = 404,
     EXTENSION = 405,
     EXTERNAL = 406,
     EXTRACT = 407,
     FALSE_P = 408,
     FAMILY = 409,
     FETCH = 410,
     FILTER = 411,
     FIRST_P = 412,
     FLOAT_P = 413,
     FOLLOWING = 414,
     FOR = 415,
     FORCE = 416,
     FOREIGN = 417,
     FORWARD = 418,
     FREEZE = 419,
     FROM = 420,
     FULL = 421,
     FUNCTION = 422,
     FUNCTIONS = 423,
     GLOBAL = 424,
     GRANT = 425,
     GRANTED = 426,
     GRAPH = 427,
     GREATEST = 428,
     GROUP_P = 429,
     GROUPING = 430,
     HANDLER = 431,
     HAVING = 432,
     HEADER_P = 433,
     HOLD = 434,
     HOUR_P = 435,
     IDENTITY_P = 436,
     IF_P = 437,
     ILIKE = 438,
     IMMEDIATE = 439,
     IMMUTABLE = 440,
     IMPLICIT_P = 441,
     IMPORT_P = 442,
     IN_P = 443,
     INCLUDING = 444,
     INCREMENT = 445,
     INDEX = 446,
     INDEXES = 447,
     INHERIT = 448,
     INHERITS = 449,
     INITIALLY = 450,
     INLINE_P = 451,
     INNER_P = 452,
     INOUT = 453,
     INPUT_P = 454,
     INSENSITIVE = 455,
     INSERT = 456,
     INSTEAD = 457,
     INT_P = 458,
     INTEGER = 459,
     INTERSECT = 460,
     INTERVAL = 461,
     INTO = 462,
     INVOKER = 463,
     IS = 464,
     ISNULL = 465,
     ISOLATION = 466,
     JOIN = 467,
     KEY = 468,
     LABEL = 469,
     LANGUAGE = 470,
     LARGE_P = 471,
     LAST_P = 472,
     LATERAL_P = 473,
     LEADING = 474,
     LEAKPROOF = 475,
     LEAST = 476,
     LEFT = 477,
     LEVEL = 478,
     LIKE = 479,
     LIMIT = 480,
     LISTEN = 481,
     LOAD = 482,
     LOCAL = 483,
     LOCALTIME = 484,
     LOCALTIMESTAMP = 485,
     LOCATION = 486,
     LOCK_P = 487,
     LOCKED = 488,
     LOGGED = 489,
     MAPPING = 490,
     MATCH = 491,
     MATERIALIZED = 492,
     MAXVALUE = 493,
     MERGE = 494,
     METHOD = 495,
     MINUTE_P = 496,
     MINVALUE = 497,
     MODE = 498,
     MONTH_P = 499,
     MOVE = 500,
     NAME_P = 501,
     NAMES = 502,
     NATIONAL = 503,
     NATURAL = 504,
     NCHAR = 505,
     NEXT = 506,
     NO = 507,
     NONE = 508,
     NOT = 509,
     NOTHING = 510,
     NOTIFY = 511,
     NOTNULL = 512,
     NOWAIT = 513,
     NULL_P = 514,
     NULLIF = 515,
     NULLS_P = 516,
     NUMERIC = 517,
     OBJECT_P = 518,
     OF = 519,
     OFF = 520,
     OFFSET = 521,
     OIDS = 522,
     ON = 523,
     ONLY = 524,
     OPERATOR = 525,
     OPTION = 526,
     OPTIONAL_P = 527,
     OPTIONS = 528,
     OR = 529,
     ORDER = 530,
     ORDINALITY = 531,
     OUT_P = 532,
     OUTER_P = 533,
     OVER = 534,
     OVERLAPS = 535,
     OVERLAY = 536,
     OWNED = 537,
     OWNER = 538,
     PARALLEL = 539,
     PARSER = 540,
     PARTIAL = 541,
     PARTITION = 542,
     PASSING = 543,
     PASSWORD = 544,
     PLACING = 545,
     PLANS = 546,
     POLICY = 547,
     POSITION = 548,
     PRECEDING = 549,
     PRECISION = 550,
     PRESERVE = 551,
     PREPARE = 552,
     PREPARED = 553,
     PRIMARY = 554,
     PRIOR = 555,
     PRIVILEGES = 556,
     PROCEDURAL = 557,
     PROCEDURE = 558,
     PROGRAM = 559,
     PROPERTY = 560,
     QUOTE = 561,
     RANGE = 562,
     READ = 563,
     REAL = 564,
     REASSIGN = 565,
     RECHECK = 566,
     RECURSIVE = 567,
     REF = 568,
     REFERENCES = 569,
     REFRESH = 570,
     REINDEX = 571,
     RELATIVE_P = 572,
     RELEASE = 573,
     REMOVE = 574,
     RENAME = 575,
     REPEATABLE = 576,
     REPLACE = 577,
     REPLICA = 578,
     RESET = 579,
     RESTART = 580,
     RESTRICT = 581,
     RETURN = 582,
     RETURNING = 583,
     RETURNS = 584,
     REVOKE = 585,
     RIGHT = 586,
     ROLE = 587,
     ROLLBACK = 588,
     ROLLUP = 589,
     ROW = 590,
     ROWS = 591,
     RULE = 592,
     SAVEPOINT = 593,
     SCHEMA = 594,
     SCROLL = 595,
     SEARCH = 596,
     SECOND_P = 597,
     SECURITY = 598,
     SELECT = 599,
     SEQUENCE = 600,
     SEQUENCES = 601,
     SERIALIZABLE = 602,
     SERVER = 603,
     SESSION = 604,
     SESSION_USER = 605,
     SET = 606,
     SETS = 607,
     SETOF = 608,
     SHARE = 609,
     SHORTESTPATH = 610,
     SHOW = 611,
     SIMILAR = 612,
     SIMPLE = 613,
     SINGLE = 614,
     SIZE_P = 615,
     SKIP = 616,
     SMALLINT = 617,
     SNAPSHOT = 618,
     SOME = 619,
     SQL_P = 620,
     STABLE = 621,
     STANDALONE_P = 622,
     START = 623,
     STATEMENT = 624,
     STATISTICS = 625,
     STDIN = 626,
     STDOUT = 627,
     STORAGE = 628,
     STRICT_P = 629,
     STRIP_P = 630,
     SUBSTRING = 631,
     SYMMETRIC = 632,
     SYSID = 633,
     SYSTEM_P = 634,
     TABLE = 635,
     TABLES = 636,
     TABLESAMPLE = 637,
     TABLESPACE = 638,
     TEMP = 639,
     TEMPLATE = 640,
     TEMPORARY = 641,
     TEXT_P = 642,
     THEN = 643,
     TIME = 644,
     TIMESTAMP = 645,
     TO = 646,
     TRAILING = 647,
     TRANSACTION = 648,
     TRANSFORM = 649,
     TREAT = 650,
     TRIGGER = 651,
     TRIM = 652,
     TRUE_P = 653,
     TRUNCATE = 654,
     TRUSTED = 655,
     TYPE_P = 656,
     TYPES_P = 657,
     UNBOUNDED = 658,
     UNCOMMITTED = 659,
     UNENCRYPTED = 660,
     UNION = 661,
     UNIQUE = 662,
     UNKNOWN = 663,
     UNLISTEN = 664,
     UNLOGGED = 665,
     UNTIL = 666,
     UPDATE = 667,
     USER = 668,
     USING = 669,
     VACUUM = 670,
     VALID = 671,
     VALIDATE = 672,
     VALIDATOR = 673,
     VALUE_P = 674,
     VALUES = 675,
     VARCHAR = 676,
     VARIADIC = 677,
     VARYING = 678,
     VERBOSE = 679,
     VERSION_P = 680,
     VIEW = 681,
     VIEWS = 682,
     VLABEL = 683,
     VOLATILE = 684,
     WHEN = 685,
     WHERE = 686,
     WHITESPACE_P = 687,
     WINDOW = 688,
     WITH = 689,
     WITHIN = 690,
     WITHOUT = 691,
     WORK = 692,
     WRAPPER = 693,
     WRITE = 694,
     XML_P = 695,
     XMLATTRIBUTES = 696,
     XMLCONCAT = 697,
     XMLELEMENT = 698,
     XMLEXISTS = 699,
     XMLFOREST = 700,
     XMLPARSE = 701,
     XMLPI = 702,
     XMLROOT = 703,
     XMLSERIALIZE = 704,
     YEAR_P = 705,
     YES_P = 706,
     ZONE = 707,
     NOT_LA = 708,
     NULLS_LA = 709,
     WITH_LA = 710,
     POSTFIXOP = 711,
     UMINUS = 712
   };
#endif



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 1676 of yacc.c  */
#line 204 "gram.y"

	core_YYSTYPE		core_yystype;
	/* these fields must match core_YYSTYPE: */
	int					ival;
	char				*str;
	const char			*keyword;

	char				chr;
	bool				boolean;
	JoinType			jtype;
	DropBehavior		dbehavior;
	OnCommitAction		oncommit;
	List				*list;
	Node				*node;
	Value				*value;
	ObjectType			objtype;
	TypeName			*typnam;
	FunctionParameter   *fun_param;
	FunctionParameterMode fun_param_mode;
	FuncWithArgs		*funwithargs;
	DefElem				*defelt;
	SortBy				*sortby;
	WindowDef			*windef;
	JoinExpr			*jexpr;
	IndexElem			*ielem;
	Alias				*alias;
	RangeVar			*range;
	IntoClause			*into;
	WithClause			*with;
	InferClause			*infer;
	OnConflictClause	*onconflict;
	A_Indices			*aind;
	ResTarget			*target;
	struct PrivTarget	*privtarget;
	AccessPriv			*accesspriv;
	struct ImportQual	*importqual;
	InsertStmt			*istmt;
	VariableSetStmt		*vsetstmt;



/* Line 1676 of yacc.c  */
#line 551 "gram.h"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif



#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif



